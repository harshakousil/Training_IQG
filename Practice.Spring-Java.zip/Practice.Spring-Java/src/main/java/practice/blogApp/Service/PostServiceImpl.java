package practice.blogApp.Service;

import practice.blogApp.Dto.PostEO;

public class PostServiceImpl implements PostService {
    @Override
    public PostEO addPost() {
        return null;
    }

    @Override
    public PostEO deletePost(String Title) {
        return null;
    }
}
