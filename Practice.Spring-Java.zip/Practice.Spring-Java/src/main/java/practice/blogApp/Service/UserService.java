package practice.blogApp.Service;

import practice.blogApp.Dto.UserEO;

public interface UserService {

    public UserEO adduser();


    public String DeleteUser(String email);

}
