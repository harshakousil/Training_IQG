var student =
{
    name:"David Reyy",
    sclass:"VI",
    rollno:12
}

delete student.rollno

console.log(student);