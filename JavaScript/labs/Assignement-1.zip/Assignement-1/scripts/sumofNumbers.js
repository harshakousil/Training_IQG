
var firstInt =5

var secondInt=7

function sumofInt(num1, num2)
{
    if(num1==num2)
    {
        return (num1+num2)*3
    }
    else{
        return num1+num2
    }
}

console.log(sumofInt(firstInt, secondInt));
