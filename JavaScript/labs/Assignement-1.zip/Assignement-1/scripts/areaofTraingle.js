var length=5
var breadth=6
var height=7

var perimeter= (5+6+7)/2

var area=Math.sqrt(perimeter*((perimeter-length)*(perimeter-breadth)*(perimeter-height)))

console.log(area);
