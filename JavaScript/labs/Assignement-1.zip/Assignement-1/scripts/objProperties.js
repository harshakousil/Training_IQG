var student=
{
    name:"David Rayy",
    Sclass: "VI",
    rollno: 12
}
Object.keys(student).forEach((value)=>{
    console.log(value);
})