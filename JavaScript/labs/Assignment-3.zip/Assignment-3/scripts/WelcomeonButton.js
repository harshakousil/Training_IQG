window.addEventListener("load",()=>
{
    document.getElementById("btn-1").addEventListener("click",()=>
    {
        alert("This conetent is diplayed after clicking the button")
    })
})