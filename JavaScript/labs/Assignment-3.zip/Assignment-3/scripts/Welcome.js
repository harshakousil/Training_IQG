window.addEventListener("load",()=>
{
    alert("Welcome to the page")
})