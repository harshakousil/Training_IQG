myColor=["Red","Green","White","Black"]

var str1=myColor.join();

var str2=myColor.join("+");
console.log(str1);
console.log(str2);
