window.addEventListener("load",()=>
{
    document.getElementById("btn-1").addEventListener("click",()=>
    {
        alert("You clicked the Button");
    })
    document.getRootNode("ul").addEventListener("load",()=>
    {
        alert("you have loaded the rootElement");
    })
})


// Note :- 4,5,6,7,8 questions anseer is already provided in odf itself