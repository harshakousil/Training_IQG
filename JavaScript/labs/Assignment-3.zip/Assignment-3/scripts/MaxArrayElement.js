function arrayMax(array)
{

    return Math.max(...array);
}
console.log(arrayMax([12,34,56,1]))
console.log(arrayMax([-12,-34,0,-56,-1]))
