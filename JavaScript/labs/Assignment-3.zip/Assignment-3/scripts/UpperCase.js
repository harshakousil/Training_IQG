function checkUpper(str)
{
    if(str.charAt(0) ==str.charAt(0).toUpperCase())
    {
        console.log("The first character of string is in UpperCase")

    }
    else{
        console.log("The First chaarcater of string is not in uppercase")
    }
}

checkUpper("kousilLakkapragada");

checkUpper("KousilLakkapragada")