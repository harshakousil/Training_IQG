function js_style()
{
   var para= document.getElementById("text")

   para.style.color="red";
   para.style.font="100px";

}