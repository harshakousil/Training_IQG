function removecolor()
{
    var collection=document.getElementById("colorSelect")

    while(collection.hasChildNodes)
    {
        collection.removeChild;
    }
}