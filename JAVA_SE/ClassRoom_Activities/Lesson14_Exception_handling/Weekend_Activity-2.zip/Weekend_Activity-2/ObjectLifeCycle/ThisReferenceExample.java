public class ThisReferenceExample {
	
	public static void main(String[] args) {
	
		DummyClass d1 = new DummyClass();

		d1.mymethod1();
	}
}