public class AverageNumber
{
 public AverageNumber()
 {
 }
 
 
 public static void main(String[] args)
 {
  int num1=10;
  int num2=20;
  int num3=45;
  
  //get the average of the three numbers
  //asn saves it inside the ave varibale
  
  int ave =(num1+num2+num3)/3;
  
  
  
  System.out.println("number 1 ="+num1);
  System.out.println("number 2 ="+num2);
  System.out.println("number 3 ="+num3);
  System.out.println("Average is ="+ ave);
  }
  }
  