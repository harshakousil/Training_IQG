public class ClassAndObject
{
 public static void main(String[] args)
 {
 String strInstance1 =new String ("I am object instance of a String class");
 
 System.out.println("Value of strInstance1 = "+ strInstance1);
 
 
 String strInstance2="Iam object instance of a String class";
 
 System.out.println("Value of strInstance2 = "+ strInstance2);
 
 String strInstance3 =new String ("I another object instance of a String class");
 
 System.out.println("Value of strInstance3 = "+ strInstance3);
 }
}