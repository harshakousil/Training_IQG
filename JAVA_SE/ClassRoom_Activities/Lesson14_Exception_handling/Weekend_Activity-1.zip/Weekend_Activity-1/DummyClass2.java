
package mynewpackage;
import myaccessmodifierexampleproject.DummyClass;
public class DummyClass2 {
public DummyClass2() {
	DummyClass t = new DummyClass();

	System.out.println("s1 = " + t.s1); 
	DummayClass class
	System.out.println("s2 = " + t.s2); 
	System.out.println("s4 = " + t.s4); 
	variable
	t.method1(); 
	t.method2(); 
	t.method4(); 

	System.out.println("s3 = " + t.s3); 
	t.method3(); 
}
}