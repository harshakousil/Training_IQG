
package myaccessmodifierexampleproject;
public class DummyClass {

	private String s1 = "private string";

	protected String s2 = "protected string";

	public String s3 = "public string";

	String s4 = "string without access modifier";

	private void method1(){
	}

	protected void method2(){
	}

	public void method3(){
	}

	void method4(){
	}
}