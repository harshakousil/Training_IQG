public class OutputVariable
{
 public static void main( String args[])
 {
 
 //variable value is int primitive type and it is
 //initialized to 10
 
  int value=10;
  
  //variable x is char primitive type and it is initializedto 'A'
  
  char x='A';
  
  
  //question -5
  //variable grade is a double type
   double grade =11;
  
  //Displaying the deatils
  
  System.out.println(value);
  
  System.out.println("The value of x = " + x);
  
  System.out.println("The value of grade =" +grade);
  }
 }
  
  
 