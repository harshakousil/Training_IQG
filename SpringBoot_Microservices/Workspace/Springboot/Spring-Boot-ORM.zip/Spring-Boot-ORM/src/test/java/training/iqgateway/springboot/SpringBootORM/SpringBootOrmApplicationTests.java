package training.iqgateway.springboot.SpringBootORM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootOrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
