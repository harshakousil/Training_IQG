//This one is using  procces command
console.log("Current Directory :", process.cwd());

//or

console.log(__filename);
// Prints: /Users/mjr/example.js
console.log(__dirname);
// Prints: /Users/mjr 