var url = require('url');
var adress = 'http://www.iqgateway.com';
var query = url.parse(adress, true);

console.log(query.host); 
console.log(query.pathname); 
console.log(query.port)
console.log(query.protocol)
const myURL = new URL('https://www.google.co.in:1234/myApplication/kousilLakkapragada');
console.log("Hostname : "+myURL.hostname);

console.log("Pathname : "+myURL.pathname);

console.log("PortNumber : "+myURL.port);

console.log("Protocal : "+myURL.protocol);

const myURLs =[
    new URL('https://www.google.com'),
    new URL('https://www.youtube.com'),
];

console.log(JSON.stringify(myURLs));