function Multiply( num1, num2)
{
    if(num1 !== undefined && num2 !== undefined)
        return num1*num2
}
console.log(Multiply(2,3))