function LionRoar()
{
    console.log("Lion is Roaring.....")
}

module.exports = {LionRoar}