buf = new Buffer(256)

len= buf.write("Node js is simple")
console.log("Octets Written :" + len);