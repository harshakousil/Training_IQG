function DateAndTime()
{
    console.log("The currrent date and time is : "+ Date.now())
}
module.exports = {DateAndTime}