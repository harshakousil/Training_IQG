let Dateobj = require('./DateTime')
let animalObj = require('./LionRoar')


function PrintDetails()
{
    Dateobj.DateAndTime()
    animalObj.LionRoar()

}

PrintDetails();