var dateobj= new Date();
var myname= "Kousil Lakkapragada"
console.log("Hello "+myname +"Welcom to Node , Date and time is "+ dateobj)

